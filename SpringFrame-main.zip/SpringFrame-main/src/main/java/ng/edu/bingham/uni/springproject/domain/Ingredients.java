package ng.edu.bingham.uni.springproject.domain;

public class Ingredients {
}
